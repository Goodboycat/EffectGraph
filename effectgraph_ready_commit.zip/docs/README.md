# EffectGraph Demo (docs)

This `docs/index.html` is a ready-to-publish demo for GitHub Pages. It uses Three.js from CDN and requires WebGL2 for the GPGPU path. The page falls back to a CPU canvas renderer if WebGL2 isn't available.
