import * as THREE from 'three';
import type { Particle } from '../types';
export class GPUEffectRenderer {
  scene:THREE.Scene; camera:THREE.PerspectiveCamera; renderer:THREE.WebGLRenderer;
  points?:THREE.Points; positions!:Float32Array; ages!:Float32Array; maxParticles:number; geometry?:THREE.BufferGeometry; material?:THREE.ShaderMaterial;
  constructor(canvas:HTMLCanvasElement,maxParticles=20000){
    this.maxParticles=maxParticles; this.scene=new THREE.Scene(); this.camera=new THREE.PerspectiveCamera(60,canvas.width/canvas.height,0.1,1000); this.camera.position.set(0,0,150);
    this.renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true}); this.renderer.setSize(canvas.width,canvas.height,false); this.renderer.setPixelRatio(window.devicePixelRatio||1);
    this.positions=new Float32Array(maxParticles*3); this.ages=new Float32Array(maxParticles);
    this.geometry=new THREE.BufferGeometry(); this.geometry.setAttribute('position', new THREE.BufferAttribute(this.positions,3).setUsage(THREE.DynamicDrawUsage));
    this.geometry.setAttribute('a_age', new THREE.BufferAttribute(this.ages,1).setUsage(THREE.DynamicDrawUsage));
    this.material=new THREE.ShaderMaterial({
      transparent:true, depthWrite:false, blending:THREE.AdditiveBlending,
      uniforms:{u_time:{value:0}, u_pointSize:{value:16.0}, u_resolution:{value:new THREE.Vector2(canvas.width,canvas.height)}},
      vertexShader:`attribute float a_age; varying float v_age; uniform float u_pointSize; void main(){ v_age=a_age; vec4 mvPos=modelViewMatrix*vec4(position,1.0); gl_PointSize=u_pointSize*(1.0-clamp(v_age,0.0,1.0)); gl_Position=projectionMatrix*mvPos; }`,
      fragmentShader:`varying float v_age; void main(){ vec2 uv=gl_PointCoord-0.5; float dist=length(uv); float alpha=smoothstep(0.5,0.0,dist); vec3 col=mix(vec3(1.0,0.8,0.2),vec3(0.2,0.5,1.0),v_age); gl_FragColor=vec4(col, alpha*(1.0-v_age)); if(gl_FragColor.a<0.01) discard; }`
    });
    this.points=new THREE.Points(this.geometry,this.material); this.scene.add(this.points);
  }
  resize(w:number,h:number){ this.renderer.setSize(w,h,false); this.camera.aspect=w/h; this.camera.updateProjectionMatrix(); (this.material!.uniforms.u_resolution.value as THREE.Vector2).set(w,h); }
  updateFromParticleArray(particles:Particle[]){ const pos=this.positions; const ages=this.ages; const n=Math.min(particles.length,this.maxParticles); for(let i=0;i<n;i++){ const p=particles[i]; const idx=i*3; pos[idx]=p.position[0]; pos[idx+1]=p.position[1]; pos[idx+2]=p.position[2]||0; const life=(p as any).__lifetime||1; ages[i]=1-Math.max(0,Math.min(1,p.life/life)); } for(let i=n;i<this.maxParticles;i++){ const idx=i*3; pos[idx]=pos[idx+1]=pos[idx+2]=1e9; ages[i]=1; } (this.geometry!.attributes.position as THREE.BufferAttribute).needsUpdate=true; (this.geometry!.attributes.a_age as THREE.BufferAttribute).needsUpdate=true; }
  render(timeSec:number){ if(this.material) (this.material.uniforms.u_time.value as number)=timeSec; this.renderer.render(this.scene,this.camera); }
  dispose(){ if(this.points){ this.scene.remove(this.points); this.geometry?.dispose(); this.material?.dispose(); } this.renderer.dispose(); }
}
