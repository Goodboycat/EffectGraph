import type { EffectSpec } from '../types';
export class EffectRunner {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private effects: any[] = [];
  private running=false; private last=0;
  constructor(canvas:HTMLCanvasElement){ this.canvas=canvas; const ctx=canvas.getContext('2d'); if(!ctx) throw new Error('2D not supported'); this.ctx=ctx; }
  addEffect(effect:{spec:EffectSpec,pool:any}){ this.effects.push(effect); }
  start(){ if(this.running) return; this.running=true; this.last=performance.now(); requestAnimationFrame(this.tick.bind(this)); }
  stop(){ this.running=false; }
  private tick(t:number){ const dt=Math.min((t-this.last)/1000,0.05); this.last=t; this.update(dt); this.render(); if(this.running) requestAnimationFrame(this.tick.bind(this)); }
  private update(dt:number){ for(const e of this.effects){ const spawned=e.spawn(dt); for(const p of spawned){ p.velocity[1]-=9.8*dt*0.2; p.position[0]+=p.velocity[0]*dt*60; p.position[1]+=p.velocity[1]*dt*60; p.position[2]+=p.velocity[2]*dt*60; p.life-=dt; if(p.life<=0) e.pool.release(p); } } }
  private render(){ const ctx=this.ctx; ctx.clearRect(0,0,this.canvas.width,this.canvas.height); ctx.fillStyle='rgba(255,200,0,0.9)'; for(const e of this.effects){ ctx.fillRect(10,10,(e.pool as any).activeCount ? (e.pool as any).activeCount()*2 : 2,10); } }
}
