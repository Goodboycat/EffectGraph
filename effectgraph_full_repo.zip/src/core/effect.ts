import { EffectSpec, Particle } from '../types';
import { ParticlePool } from './particlePool';
export function createEffect(spec: EffectSpec) {
  const cfg = { emitRate: spec.emitRate ?? 10, maxParticles: spec.maxParticles ?? 100, lifetime: spec.lifetime ?? 1.5 };
  const pool = new ParticlePool(cfg.maxParticles);
  return { spec: cfg, pool, spawn(dt:number){ const toSpawn=Math.floor(cfg.emitRate*dt); const spawned:Particle[]=[]; for(let i=0;i<toSpawn;i++){ const p=pool.acquire(); p.position[0]=(Math.random()-0.5)*200; p.position[1]=Math.random()*200; p.position[2]=(Math.random()-0.5)*200; p.velocity[0]=(Math.random()-0.5)*2; p.velocity[1]=Math.random()*2; p.velocity[2]=(Math.random()-0.5)*2; p.life=cfg.lifetime; p.__lifetime=cfg.lifetime; p.alive=true; spawned.push(p);} return spawned; } };
