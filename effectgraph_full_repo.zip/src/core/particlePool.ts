import { Particle } from '../types';
export class ParticlePool {
  private pool: Particle[] = [];
  private inUse: Set<Particle> = new Set();
  constructor(size = 100) { for (let i=0;i<size;i++) this.pool.push(this._createParticle()); }
  private _createParticle(): Particle { return { position:[0,0,0], velocity:[0,0,0], life:0, alive:false }; }
  acquire(): Particle { const p = this.pool.pop() || this._createParticle(); this.inUse.add(p); return p; }
  release(p: Particle){ p.alive=false; p.life=0; p.velocity=[0,0,0]; p.position=[0,0,0]; this.inUse.delete(p); this.pool.push(p); }
  activeCount(){ return this.inUse.size; }
  snapshot(){ return Array.from(this.inUse); }
}
